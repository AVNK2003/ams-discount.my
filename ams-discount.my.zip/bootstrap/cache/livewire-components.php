<?php return array (
  'comments' => 'App\\Http\\Livewire\\Comments',
);