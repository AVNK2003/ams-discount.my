<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    use HasFactory;

    protected $fillable = ['user_id','org','title','img','address','working_hours','tel','site','discount', 'description','instagram','vk','facebook','youtube','active','priority','coordinates', 'views'];

    protected $with = ['categories', 'cities'];

    public function Partners()
    {
        return $this->hasOne(Partner::class, 'id', 'user_id');
    }

    public function Categories()
    {
        return $this->belongsToMany(Category::class);
    }

    public function Cities()
    {
        return $this->belongsToMany(City::class);
    }

    public function makeLinkTel()
    {
        return preg_replace_callback('/(\+?\d*)?[\s\-]?((\(\d+\)|\d+)[\s\-]?)?(\d[\s\-]?){7,11}\b/',
            function ($matches) {
                $link = preg_replace("/[^0-9]/", '', $matches[0]);

                if ($link[0] == 7)
                    $link = '+' . $link;

                return '<a href="tel:'.$link.'">'.$matches[0].'</a>';
            },
            $this->tel);
    }
}
