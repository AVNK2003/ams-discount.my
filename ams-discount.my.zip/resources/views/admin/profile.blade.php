@extends('layouts.layout')
@section('title', '- Профиль пользователя')
@section('linksAside')
    <x-aside-links-admins/>@endsection
@section('content')
    <x-success-session/>
    <h1 class="text-2xl mb-2 text-center">Профиль пользователя</h1>
    <x-validation />
    <div class="flex flex-wrap gap-4">
        <form action="{{ route('partners.update', [auth()->user()]) }}" class="form" method="post">
            @method('PUT')
            @csrf
            <div class="form__wrap">
                <label class="label" for="name">Имя</label>
                <input class="input @error('name') is-invalid @enderror" type="text" placeholder="Как к вам обращаться"
                       id="name" name="name" value="{{ old('name') ?? auth()->user()->name }}" required>
            </div>

            <div class="form__wrap">
                <label class="label" for="email">Email</label>
                <input class="input @error('email') is-invalid @enderror" type="text" placeholder="mail@mail.ru"
                       id="email" name="email" value="{{ old('email') ?? auth()->user()->email }}" required>
            </div>

            <div class="form__wrap">
                <label class="label" for="tel">Телефон</label>
                <input class="input @error('tel') is-invalid @enderror" type="tel" placeholder="+79781234567" id="tel"
                       name="tel" value="{{ old('tel') ?? auth()->user()->tel }}" required>
            </div>

            <div class="form__wrap">
                <button class="btn btn-red w-full" type="submit">Изменить</button>
            </div>
        </form>

        <div class="mx-auto">
        <h2 class="text-xl mb-2 text-center">Изменение пароля</h2>

        <form action="{{ route('passwordChange', [auth()->user()]) }}" class="form" method="post">
            @method('PUT')
            @csrf
            <div class="form__wrap">
                <label class="label" for="password">Пароль</label>
                <input class="input" type="password" placeholder="Новый пароль"
                       id="password" name="password" required>
            </div>

            <div class="form__wrap">
                <label class="label" for="password_confirmation">Подтверждение пароля</label>
                <input class="input" type="password" placeholder="Подтверждение пароля"
                       id="password_confirmation" name="password_confirmation" required>
            </div>

            <div class="form__wrap">
                <button class="btn btn-red w-full" type="submit">Изменить пароль</button>
            </div>
        </form>
        </div>
    </div>
@endsection

@section('scriptsFooter')
    <script src="https://unpkg.com/imask"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const inputElement = document.querySelector('#tel');
            const maskOptions = {
                mask: '+{7} (000) 000-00-00',
            }
            IMask(inputElement, maskOptions);
        });
    </script>
@endsection
