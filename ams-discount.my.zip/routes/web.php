<?php

use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [\App\Http\Controllers\CompanyController::class, 'indexForAll'])->name('home');

Route::get('/email/verify', function () {
    return view('auth.verify-email');
})->middleware('auth')->name('verification.notice');

Route::get('/email/verify/{id}/{hash}', function (EmailVerificationRequest $request) {
    $request->fulfill();
    return redirect('/cabinet/verify');
})->middleware(['auth', 'signed'])->name('verification.verify');

Route::get('/cabinet/verify');

Route::get('/company/{company}', [\App\Http\Controllers\CompanyController::class, 'showCompanyForAll'])->name('showCompany');

Route::get('/category/{category:slug}', [\App\Http\Controllers\CategoryController::class, 'showCategory'])->name('showCategory');

Route::get('/city/{city:slug}', [\App\Http\Controllers\CityController::class, 'showCity'])->name('showCity');

Route::get('/page/{page:slug}', [\App\Http\Controllers\PageController::class, 'show'])->name('showPage');

Route::get('/cabinet', function () {
    return view('admin.index');
})->middleware(['auth'])->name('admin');

Route::prefix('cabinet')->group(function () {
    Route::resource('companies', \App\Http\Controllers\CompanyController::class)->middleware(['auth']);
    Route::put('companies/{company}/moderate', [\App\Http\Controllers\CompanyController::class, 'toggleActive'])->name('toggleActive');
    Route::resource('partners', \App\Http\Controllers\PartnerController::class)->middleware(['auth']);
    Route::put('passwordChange', [\App\Http\Controllers\PartnerController::class, 'passwordChange'])->middleware(['auth'])->name('passwordChange');
    Route::resource('cities', \App\Http\Controllers\CityController::class)->middleware(['auth']);
    Route::resource('categories', \App\Http\Controllers\CategoryController::class)->middleware(['auth']);
    Route::resource('comments', \App\Http\Controllers\CommentController::class)->middleware(['auth']);
    Route::put('comments/{comment}/moderate', [\App\Http\Controllers\CommentController::class, 'togglePublish'])->name('togglePublish');
    Route::resource('pages', \App\Http\Controllers\PageController::class)->middleware(['auth']);

    Route::get('profile', function () {
        return view('admin.profile');
    })->middleware(['auth'])->name('profile');
});

Route::get('/clear', function () {
    Artisan::call('cache:clear');
    Artisan::call('config:cache');
    Artisan::call('view:clear');
    Artisan::call('route:clear');

    return "Кэш очищен.";
});

require __DIR__.'/auth.php';
