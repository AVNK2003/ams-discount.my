<?php echo $__env->make('components.validation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form class="w-full max-w-[640px] p-4 border border-gray-500 shadow-lg rounded-md mx-auto bg-[#222222]" action="<?php echo e(route('pages.store')); ?>" method="post">
    <?php echo csrf_field(); ?>

    <div class="form__wrap">
        <label class="label" for="ico">Иконка</label>
        <input class="input" type="text" placeholder="Название иконки" id="ico" name="ico" value="<?php echo e(old('ico')); ?>" required>
    </div>

    <div class="form__wrap">
        <label class="label" for="title">Название страницы</label>
        <input class="input" type="text" placeholder="Название которое будут видеть посетители" id="title" name="title" value="<?php echo e(old('title')); ?>" required>
    </div>

    <div class="form__wrap">
        <label class="label" for="slug">Адрес страницы</label>
        <input class="input" type="text" placeholder="Адрес в строке браузера" id="slug" name="slug" value="<?php echo e(old('slug')); ?>" required>
    </div>

    <div class="form__wrap">
        <label for="text">Статья</label>
        <textarea id="text" name="text"><?php echo e(old('text')); ?></textarea>
    </div>
    <div class="form__wrap">
        <button class="btn btn-red w-full" type="submit">Добавить</button>
    </div>
</form>
<?php /**PATH D:\OpenServer\domains\ams-discount.my\resources\views/components/page/create.blade.php ENDPATH**/ ?>