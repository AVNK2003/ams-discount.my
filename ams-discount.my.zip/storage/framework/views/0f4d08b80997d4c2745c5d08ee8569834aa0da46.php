<form action="<?php echo e(route('password.email')); ?>" class="form" method="POST">
    <?php echo csrf_field(); ?>

    <div class="form__wrap">
        <label class="label" for="email">Email</label>
        <input class="input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" placeholder="Email указанный при регистрации" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
    </div>
    <div class="form__wrap">
        <button class="btn btn-red w-full"
                type="submit">
            Выслать ссылку на почту
        </button>
    </div>

    <div class="form__footer">
        <div class="w-1/2 text-center">
            <a
                class="link"
                href="<?php echo e(route('register')); ?>">
                Регистрация
            </a>
        </div>
        <div class="w-1/2 text-center">
            <a
                class="link"
                href="<?php echo e(route('login')); ?>">
                Страница входа
            </a>
        </div>
    </div>
</form>
<?php /**PATH D:\OpenServer\domains\ams-discount.my\resources\views/components/forgot-password-form.blade.php ENDPATH**/ ?>