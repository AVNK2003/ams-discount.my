<?php echo $__env->make('components.validation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form class="form" action="<?php echo e(route('cities.update', [$city])); ?>" class="form" method="post">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>

    <div class="form__wrap">
        <label class="label" for="name">Город</label>

        <input
            class="input"
            type="text"
            placeholder="Ялта"
            id="name"
            name="name"
            value="<?php echo e(old('name') ?? $city->name); ?>"
            required
        >

    </div>

    <div class="form__wrap">
        <label class="label" for="slug">Ссылка (латиница)</label>
        <input
            class="input"
            type="text"
            placeholder="yalta"
            id="slug"
            name="slug"
            value="<?php echo e(old('slug') ?? $city->slug); ?>"
            required
        >

    </div>
    <div class="form__wrap">
        <button class="btn btn-red w-full" type="submit">Изменить</button>
    </div>
</form>
<?php /**PATH D:\OpenServer\domains\ams-discount.my\resources\views/components/city/edit.blade.php ENDPATH**/ ?>