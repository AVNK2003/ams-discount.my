<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [\App\Http\Controllers\CompanyController::class, 'indexForAll'])->name('home');

Route::get('/company/{company}', [\App\Http\Controllers\CompanyController::class, 'showCompanyForAll'])
    ->name('showCompany');

Route::get('/category/{category:slug}', [\App\Http\Controllers\CategoryController::class, 'showCategory'])
    ->name('showCategory');

Route::get('/city/{city:slug}', [\App\Http\Controllers\CityController::class, 'showCity'])->name('showCity');

Route::get('/page/{page:slug}', [\App\Http\Controllers\PageController::class, 'show'])->name('showPage');

Route::prefix('cabinet')->middleware(['auth'])->group(
    function () {
        Route::view('/', 'admin.index')->name('admin');

        Route::resource('companies', \App\Http\Controllers\CompanyController::class);

        Route::put('companies/{company}/moderate', [\App\Http\Controllers\CompanyController::class, 'toggleActive'])
            ->name('toggleActive');

        Route::resource('partners', \App\Http\Controllers\PartnerController::class);

        Route::put('passwordChange', [\App\Http\Controllers\PartnerController::class, 'passwordChange'])
            ->name('passwordChange');

        Route::get('admins', [\App\Http\Controllers\PartnerController::class, 'indexAdmins'])
            ->name('partners.admins');

        Route::put('toggle-admin/{admin}', [\App\Http\Controllers\PartnerController::class, 'toggleAdmin'])
            ->name('partners.admin.toggle');

        Route::resource('cities', \App\Http\Controllers\CityController::class);

        Route::resource('categories', \App\Http\Controllers\CategoryController::class);

        Route::resource('comments', \App\Http\Controllers\CommentController::class);

        Route::put(
            'comments/{comment}/moderate',
            [\App\Http\Controllers\CommentController::class, 'togglePublish']
        )->name('togglePublish');

        Route::resource('pages', \App\Http\Controllers\PageController::class);

        Route::view('profile','admin.profile')->name('profile');

        Route::post(
            '/clear',
            function () {
                if (auth()->user()->tel == '+7 (978) 109-11-56') {
                    Artisan::call('optimize:clear');
                    return redirect()->back()->with('success', 'Кэш очищен');
                }
                abort(403);
            }
        )->name('clearAllConfig');
    }
);

require __DIR__ . '/auth.php';
