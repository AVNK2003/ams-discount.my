@if(session('success'))

    <div x-data="{open: true}" x-show.transition.opacity.duration.500="open" @click.away="open=false" class="success w-44 font-medium">
            {{ session('success') }}
    </div>
@endif
